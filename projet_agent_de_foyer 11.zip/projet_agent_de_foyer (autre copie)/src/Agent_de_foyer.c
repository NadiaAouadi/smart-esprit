#include <stdio.h>
#include <string.h>
#include <Agent_de_foyer.h>
#include <gtk/gtk.h>





void ajouter(agent p)
{

FILE *f;
f=fopen("agent.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s  \n",p.cin,p.nom,p.prenom,p.date_naissance,p.telephone,p.specialite,p.niveau,p.chambre);
fclose(f);
}
}
void afficher(GtkWidget *liste)
{

enum
{
CIN,
NOM,
PRENOM,
DATE,
TELEPHONE,
SPECIALITE,
NIVEAU,
CHAMBRE,
COLUMNS,
};


GtkCellRenderer *renderer;

GtkTreeViewColumn *column;

GtkTreeIter iter;

GtkListStore *store;
char cin[20];
char nom[30];
char prenom[30];
char date[30];
char telephone[20];
char specialite[20];
char niveau[20];
char chambre[30];
store=NULL;
 
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Id",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date de naissance",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",SPECIALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("niveau universitaire",renderer,"text",NIVEAU,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",CHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("agent.txt","r");
if(f==NULL)
return;
else
{
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",cin,nom,prenom,date,telephone,specialite,niveau,chambre)!=EOF)
{
gtk_list_store_append(store,&iter);

gtk_list_store_set(store,&iter,CIN,cin,NOM,nom,PRENOM,prenom,DATE,date,TELEPHONE,telephone,SPECIALITE,specialite,NIVEAU,niveau,CHAMBRE,chambre,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}
//fonction rechercher
void supprimer(char id[])
{
char cin[30];
char nom[20];
char prenom[30];
char date[30];
char telephone[30];
char specialite[20];
char niveau[20];
char chambre[30];
FILE *f,*g;
f=fopen("agent.txt","r");
g=fopen("dump.txt","w");
if(f==NULL||g==NULL)
return ;
else
{
while(fscanf(f,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date,telephone,specialite,niveau,chambre)!=EOF)
{
if(strcmp(id,cin)==0)
continue;
else
fprintf(g,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date,telephone,specialite,niveau,chambre);
}
fclose(f);
fclose(g);
remove("agent.txt");
rename("dump.txt","agent.txt");
}

}
//fonction modifier 
void modifier(agent p)
{
char cin[30];
char nom[20];
char prenom[30];
char date[30];
char telephone[30];
char specialite[20];
char niveau[20] ; 
char chambre[30];
FILE *f,*g;
f=fopen("agent.txt","r");
g=fopen("dump.txt","w");
if(f==NULL||g==NULL)
return ;
else
while(fscanf(f,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date,telephone,specialite,niveau,chambre)!=EOF)
{
if(strcmp(p.cin,cin)==0)
fprintf(g,"%s %s %s %s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.telephone,p.specialite,p.niveau,p.chambre);
else
fprintf(g,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date,telephone,specialite,niveau,chambre);
}
fclose(f);
fclose(g);
remove("agent.txt");
rename("dump.txt","agent.txt");
}
//fonction rechercher
void rechercher(char nomFichier[],char texte[],char id[])
{
char cin[20],nom[20],prenom[20],telephone[20],date[20],specialite[20],niveau[20],chambre[30];
char retour_ligne[]="\n";
FILE *f=fopen(nomFichier,"r");
if(f!=NULL)
{while(fscanf(f,"%s %s %s %s %s %s %s %s  \n",cin,nom,prenom,date,telephone,specialite,niveau,chambre)!=EOF)
{
if(strcmp(cin,id)==0)
{strcat(texte,"id:");
strcat(texte,cin);
strcat(texte,retour_ligne);
strcat(texte,"nom:");
strcat(texte,nom);
strcat(texte,retour_ligne);
strcat(texte,"prenom:");
strcat(texte,prenom);
strcat(texte,retour_ligne);
strcat(texte,"date de naissance:");
strcat(texte,date);
strcat(texte,retour_ligne);
strcat(texte,"telephone:");
strcat(texte,telephone);
strcat(texte,retour_ligne);
strcat(texte,"specialite:");
strcat(texte,specialite);
strcat(texte,"niveau:");
strcat(texte,specialite);



break;}}
}
}

enum
{
ID,
JOUR,
MOIS,
ANNEE,
VALEUR,
COLS
};





void afficher_agent_rechercher(GtkWidget *liste,char id[])
{
enum
{
CIN,
NOM,
PRENOM,
DATE,
TELEPHONE,
SPECIALITE,
NIVEAU,
CHAMBRE,
COLUMNS,
};

GtkCellRenderer *renderer;

GtkTreeViewColumn *column;

GtkTreeIter iter;

GtkListStore *store;
char cin[20];
char nom[30];
char prenom[30];
char date[30];
char telephone[20];
char specialite[20];
char niveau[20];
char chambre[30];
store=NULL;
 
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Id",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date de naissance",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",SPECIALITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("niveau",renderer,"text",NIVEAU,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",CHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);






store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("agent.txt","r");
if(f==NULL)
return;
else
{
while(fscanf(f,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date,telephone,specialite,niveau,chambre)!=EOF)
{if(strcmp(id,cin)==0)
{gtk_list_store_append(store,&iter);

gtk_list_store_set(store,&iter,CIN,cin,NOM,nom,PRENOM,prenom,DATE,date,TELEPHONE,telephone,SPECIALITE,specialite,NIVEAU,niveau,CHAMBRE,chambre,-1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void resultat(int choix , char texte[] ) 
{
if(choix == 1 ) 
strcpy(texte , "A1");
else if (choix == 2)
strcpy(texte , "A2");
else if (choix == 3)
strcpy(texte , "A3");

}


void resultat_modif(int choix , char texte[] ) 
{
if(choix == 1 ) 
strcpy(texte , "A1");
else if (choix == 2)
strcpy(texte , "A2");
else if (choix == 3)
strcpy(texte , "A3");

}




