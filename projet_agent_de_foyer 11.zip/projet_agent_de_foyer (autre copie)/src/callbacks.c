#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Agent_de_foyer.h"
#include <stdlib.h>
char texte[30];
char texte_modif[30];
int choix = 3; 
int choix_modif = 1;
void
on_afficher_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(button,"fenetre_ajout");
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(fenetre_ajout);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher(treeview1);
int choix_modif = 1;

}
void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
agent p;
GtkWidget *input1, *input2 ,*input3,*input5;
GtkWidget *combobox1,*combobox2,*combobox3,*combobox4;
GtkWidget *spinbutton;
GtkWidget *fenetre_ajout;
char s[20];
char j[20];
char m[20];
char an[20];
char niveau_[20];
char chambre[30];
char specialite[30];
int niveau;


fenetre_ajout=lookup_widget(button,"fenetre_ajout");

input1=lookup_widget(button,"cin");
input2=lookup_widget(button,"nom");
input3=lookup_widget(button,"prenom");
input5=lookup_widget(button,"telephone");
combobox1=lookup_widget(button,"FTcomboboxj");
combobox2=lookup_widget(button,"FTcomboboxm");
combobox3=lookup_widget(button,"FTcomboboxan");
combobox4=lookup_widget(button,"comboboxSp");
spinbutton=lookup_widget(button,"spinbuttonNiveau");

strcpy(j,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(m,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(an,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(p.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

sprintf(p.date_naissance,"%s/%s/%s",j,m,an);
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));

strcpy(p.telephone,gtk_entry_get_text(GTK_ENTRY(input5)));

niveau = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton));
sprintf(niveau_,"%d",niveau);
strcpy(p.niveau,niveau_);

resultat(choix ,texte);
strcpy(p.chambre ,texte) ;



ajouter(p);


}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nom;
gchar *prenom;
gchar *date;
gchar *telephone;
gchar *cin;
gchar *specialite;
gchar *niveau;
gchar *chambre;
GtkWidget *fenetre_afficher, *treeview1;
agent p;


GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model, &iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&cin,1,&nom,2,&prenom,3,&date,4,&telephone,5,&specialite,6,&niveau,7,&chambre,-1);
strcpy(p.cin,cin);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.date_naissance,date);
strcpy(p.telephone,telephone);
strcpy(p.specialite,specialite);
strcpy(p.niveau,niveau);
strcpy(p.chambre,chambre);
	
supprimer(p.cin);

fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher(treeview1);
fenetre_afficher=lookup_widget(treeview,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);

}

}


void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_afficher;
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
fenetre_ajout=lookup_widget(button,"fenetre_ajout");
fenetre_ajout=create_fenetre_ajout();
gtk_widget_show(fenetre_ajout);
gtk_widget_destroy(fenetre_afficher);

choix = 3;
}



int confirmer;
int *confirm=&confirmer;


void
on_FTbutton_supp_clicked               (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *input,*treeview;
GtkWidget *fenetre_afficher;






char id[20];
input=lookup_widget(button,"FTentry_supp");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
if(confirmer)
{supprimer(id);
fenetre_afficher=create_fenetre_afficher();
treeview=lookup_widget(fenetre_afficher,"treeview1");
gtk_widget_show(fenetre_afficher);
afficher(treeview);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);}



}

void
on_FTcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(togglebutton))
*confirm=1;
else
*confirm=0;

}


void
on_FTbutton_actualiser_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{

GtkWidget *treeview1;
GtkWidget *fenetre_afficher;




fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher(treeview1);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
}
agent tab[1000];
int n;

void
on_FTmodifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

agent p;
GtkWidget *input1, *input2 ,*input3,*input4,*input5,*input6,*input7,*treeview,*combobox;
GtkWidget *fenetre_afficher;
int niveau;
char niveau_[20];
char chambre[30];
char specialite[30];
input1=lookup_widget(button,"FTcin_modif");
input2=lookup_widget(button,"FTnom_modif");
input3=lookup_widget(button,"FTprenom_modif");
input4=lookup_widget(button,"FTdate_naissance_modif");
input5=lookup_widget(button,"FTtelephone_modif");
input7=lookup_widget(button,"FTspinbuttonNiveauModif");
combobox=lookup_widget(button,"comboboxSpModif");


strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.telephone,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(p.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
niveau = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
sprintf(niveau_,"%d",niveau);
strcpy(p.niveau,niveau_);
resultat_modif(choix_modif,texte_modif);
strcpy(p.chambre,texte_modif);
modifier(p);
choix_modif = 1;
fenetre_afficher=create_fenetre_afficher();
treeview=lookup_widget(fenetre_afficher,"treeview1");
gtk_widget_show(fenetre_afficher);
afficher(treeview);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);

}


void
on_FTbuttonrech_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
char id[30];
GtkWidget *fenetre_afficher,*input;
GtkWidget *treeview1;
input=lookup_widget(button,"FTentryrech");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_agent_rechercher(treeview1,id);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);



}

// initaialisation button radio 

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=1; 
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=2;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=3;
}


void
on_A1_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix_modif=1; 

}


void
on_A2_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix_modif=2; 
}


void
on_A3_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix_modif=3; 

}

