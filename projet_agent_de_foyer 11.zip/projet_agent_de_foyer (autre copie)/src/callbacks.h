#include <gtk/gtk.h>



void
on_afficher_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbutton_supp_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FTbutton_actualiser_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbuttonvalider_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTmodifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_FTradiobutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FTradiobutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FTbuttonabs_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbuttonmarquer_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbuttonreturn_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbuttonrefresh_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_FTbuttoncharger_id_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTradiobutton_pres_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FTradiobutton_abs_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_FTtreeview2_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_FTbuttonrech_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_A1_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_A2_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_A3_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
