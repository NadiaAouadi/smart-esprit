#include <gtk/gtk.h>


void
on_button2home_clicked                 ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button3refresh_clicked               ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button1serch_clicked                 ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button4delate_clicked                ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button5add_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_button6capt_clicked                 ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttondiffective_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_logincapt_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button30_clicked                    ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

//void
//on_button32_clicked                    (GtkWidget      *objet_graphique,
                                        //gpointer         user_data);

void
on_button30_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_radiobutton1hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button31refrech_clicked              ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button30hanen_clicked               ( GtkWidget      *objet_graphique,
                                        gpointer         user_data);
