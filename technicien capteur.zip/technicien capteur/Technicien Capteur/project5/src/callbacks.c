#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "capteur.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdlib.h>
int x,y,z[]={0,0,0,0};
/*void
on_button2home_clicked                  ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *windowespace_recherche, *windowespace_technicien;
	windowespace_recherche=lookup_widget (objet_graphique,"techcapt");
	windowespace_recherche=create_techcapt();
	gtk_widget_show(windowespace_recherche);

	windowespace_technicien=lookup_widget (objet_graphique,"gestioncapt");
	gtk_widget_destroy(windowespace_technicien);

}*/

void
on_button3refresh_clicked               ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview,*label27erreurrecherche,*label11capt,*label19capt,*label26capt;
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	treeview=lookup_widget (gestioncapt,"treeview1hanen");
	afficher_capt(treeview,"capteur.txt");
	label27erreurrecherche=lookup_widget(objet_graphique,"label27erreurrecherche");
	gtk_label_set_text(GTK_LABEL(label27erreurrecherche),"");
	label11capt=lookup_widget(objet_graphique,"label11capt");
	gtk_label_set_text(GTK_LABEL(label11capt),"");
	label19capt=lookup_widget(objet_graphique,"label19capt");
	gtk_label_set_text(GTK_LABEL(label19capt),"");
	label26capt=lookup_widget(objet_graphique,"label26capt");
	gtk_label_set_text(GTK_LABEL(label26capt),"");
	
	
}

void
on_button1serch_clicked                 ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *ref,*treeview,*gestioncapt,*label27erreurrecherche;
	char ref1[20];
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	treeview=lookup_widget (gestioncapt,"treeview1hanen");
	ref=lookup_widget (objet_graphique,"entry1capt");
	strcpy(ref1,gtk_entry_get_text(GTK_ENTRY(ref)));
	if(strcmp(ref1,"")!=0)
	{
		if(existcapt(ref1))
		{
			rechercher(ref1);
			afficher_capt(treeview,"recherche.txt");
			remove("recherche.txt");
		}
		else{
			label27erreurrecherche=lookup_widget(objet_graphique,"label27erreurrecherche");
			gtk_label_set_text(GTK_LABEL(label27erreurrecherche),"Reference n'existe pas");
		}
	}
	else
		afficher_capt(treeview,"capteur.txt");
}


void
on_button4delate_clicked                ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview,*label11capt;
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
	gchar* ref;
	gint zone;
	gint min;
	gint max;
	gint etat;
	gint type;
	
	gestioncapt=lookup_widget(objet_graphique,"gestioncapt");
        treeview=lookup_widget(gestioncapt,"treeview1hanen");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_tree_model_get (model,&iter,0,&ref,1,&zone,2,&min,3,&max,4,&etat,5,&type,-1);
		supprimer_capt(ref,"capteur.txt");
		supprimer_capt(ref,"temperature.txt");
		supprimer_capt(ref,"mouvement.txt");
		supprimer_capt(ref,"smoke.txt");
		supprimer_capt(ref,"debit.txt");
		supprimer_capt(ref,"temperaturedef.txt");
		supprimer_capt(ref,"mouvementdef.txt");
		supprimer_capt(ref,"smokedef.txt");
		supprimer_capt(ref,"debitdef.txt");
		afficher_capt(treeview,"capteur.txt");
		label11capt=lookup_widget(objet_graphique,"label11capt");
		gtk_label_set_text(GTK_LABEL(label11capt),"capteur supprimée");
	}
}


void
on_button5add_clicked                   ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	
	GtkWidget *captref,*captzone,*captmin,*captmax,*capttype,*label19capt,*labelajout;
	int b=1;
	capteur c;
	captref=lookup_widget (objet_graphique,"entry2capt");
	captmax=lookup_widget (objet_graphique,"spinbutton1hanen");
	captmin=lookup_widget (objet_graphique,"spinbutton2hanen");
	capttype=lookup_widget (objet_graphique,"comboboxtype_capteur");
	captzone=lookup_widget (objet_graphique,"comboboxentrytype");
	labelajout=lookup_widget (objet_graphique,"label32");
	strcpy(c.captref,gtk_entry_get_text(GTK_ENTRY(captref)));
	if(strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=1;
	else if(strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=2;
	
	else
		c.captzone=3;
	if(strcmp("Temperature",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=0;
	else if(strcmp("Mouvement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=1;
	else if(strcmp("Fumer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=2;
	else
		c.type=3;
	
	c.c.captvaleurmax=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmax));
	c.c.captvaleurmin=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmin));
	c.etat=y;
      if(strcmp(c.captref,"")==0){
	gtk_widget_show (labelajout);
	b=0;}
	else{
	gtk_widget_hide (labelajout);
	}
	if(b==1){
	ajout_capt(c);
	label19capt=lookup_widget(objet_graphique,"label19capt");
	gtk_label_set_text(GTK_LABEL(label19capt),"verifier vos données");
	}

}


void
on_button6capt_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *captref,*captzone,*captmin,*captmax,*capttype,*label26capt;
	
	capteur c;
	captref=lookup_widget (objet_graphique,"entry3capt");
	captmax=lookup_widget (objet_graphique,"spinbutton3hanen");
	captmin=lookup_widget (objet_graphique,"spinbutton4hanen");
	capttype=lookup_widget (objet_graphique,"comboboxentry5");
	captzone=lookup_widget (objet_graphique,"comboboxentry2");
	strcpy(c.captref,gtk_entry_get_text(GTK_ENTRY(captref)));
	if(strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=1;
	else if(strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=2;
	
	else
		c.captzone=3;
	if(strcmp("Temperature",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=0;
	else if(strcmp("Mouvement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=1;
	else if(strcmp("Fumer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=2;
	else
		c.type=3;
	
	c.c.captvaleurmax=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmax));
	c.c.captvaleurmin=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmin));
	c.etat=x;
	modifier_capt(c);
	label26capt=lookup_widget(objet_graphique,"label26capt");
	gtk_label_set_text(GTK_LABEL(label26capt),"Modification Enregistrée");
	
}

void
on_radiobutton1hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		y=1;
	}
}


void
on_radiobutton2hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		y=0;
	}
}


void
on_radiobutton3hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		x=1;
	}
}


void
on_radiobutton4hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		x=0;
	}
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{// non supprimer
// Das loschen dieser tabelle ist in der anzeige nicht wichtig

}


void
on_checkbutton1hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		z[0]=1;


}


void
on_checkbutton2hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		z[1]=1;

}


void
on_checkbutton3hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		z[2]=1;

}


void
on_checkbutton4hanen_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton))
		z[3]=1;

}


void
on_buttondiffective_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview,*cb1,*cb2,*cb3,*cb4;
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	cb1=lookup_widget (objet_graphique,"checkbutton1hanen");
	cb2=lookup_widget (objet_graphique,"checkbutton2hanen");
	cb3=lookup_widget (objet_graphique,"checkbutton3hanen");
	cb4=lookup_widget (objet_graphique,"checkbutton4hanen");
	treeview=lookup_widget (gestioncapt,"treeview2hanen");
	capteurparchoix(z);
	afficher_capt(treeview,"capteurchoix.txt");
	remove("capteurchoix.txt");
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb1), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb2), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb3), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb4), FALSE);
	z[0]=0;
	z[1]=0;
	z[2]=0;
	z[3]=0;

}
void
on_button30hanen_clicked                    ( GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
       char resultat[200]="";
	GtkWidget *aff,*aff1;	
	FILE *f,*g;
	f=fopen("temperature1.txt","r");
	g=fopen("capteurdefectueux.txt","a+");
	capteurTemperature c,T[5000];
	int i=0,n=0,nb=0;
	if(f!=NULL){
			
			while(!feof(f))
			{
				fscanf(f,"%d %d %d %f\n",&c.jourc,&c.heurec,&c.numC,&c.valT);
				
				T[i].jourc=c.jourc;
				T[i].heurec=c.heurec;
				T[i].numC=c.numC;
				T[i].valT=c.valT;
				i++;
			}
			fclose(f);
			n=i;
	}
	for(i=0;i<n;i++){
		if(T[i].valT<10 || T[i].valT>30){
			fprintf(g,"%d %d %d %f\n",T[i].jourc,T[i].heurec,T[i].numC,T[i].valT);
			nb++;
		}
	}
	sprintf(resultat,"le nombre de capteur defecteux est :%d/%d\n",nb,n);

        aff=lookup_widget(objet_graphique,"label29hanen");
	gtk_label_set_text(GTK_LABEL(aff),resultat);

}

void
on_treeview3hanen_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *gestioncapt;	
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;

	gchar* nmrcapt;
	gchar* valtemp;
	
	
	capteurTemperature c;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		//obtention des valeurs de la ligne selectionnée

		gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &jour, 1, &heure, 2, &nmrcapt, 3, &valtemp, -1);
		//copie des valeurs dans la variable P de type personne pour le passer  à la fonction de suppression
		strcpy(jour,jour);
		strcpy(heure,heure);
		strcpy(nmrcapt,nmrcapt);
		strcpy(valtemp,valtemp);
		
		//mise a jour de l'affichage de la treeview
		afficher_captdefectueux(treeview,"capteurdefectueux.txt");
}
}
void
on_button31refrech_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview3hanen;
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	treeview3hanen=lookup_widget (gestioncapt,"treeview3hanen");
	

	afficher_captdefectueux(treeview3hanen,"capteurdefectueux.txt");
	
}
