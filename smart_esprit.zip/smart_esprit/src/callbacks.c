#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Agent_de_foyer.h"
#include "fonction.h"
#include "capteur.h"
#include "personne.h"
#include <stdlib.h>


/* -------------------------- AGENT FOYER -----------------------------*/
	/* ------------- VARIABLES GLOBALES ---------------*/ 
char texte[30];
char texte_modif[30];
int choix = 3; 
int choix_modif = 1;

int confirmer;
int *confirm=&confirmer;

agent tab[1000];
int n;
/* ------------------------- GESTION DES UTULISATEURS --------------------------- */


void
on_addUser_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{

Personne p;
int age1;
char age2[30];

GtkWidget *input1_nadia, *input2_nadia, *input3_nadia, *input4_nadia, *input5_nadia;
GtkWidget *window1_nadia;
GtkWidget *combobox1_nadia;
GtkWidget *togglebutton1_nadia, *togglebutton2_nadia;
GtkWidget *spinbutton_age_nadia;

window1_nadia=lookup_widget(objet,"window1_nadia");

input1_nadia=lookup_widget(objet,"input1_nadia");
input2_nadia=lookup_widget(objet,"input2_nadia");
input3_nadia=lookup_widget(objet,"input3_nadia");
input4_nadia=lookup_widget(objet,"input4_nadia");
input5_nadia=lookup_widget(objet,"input5_nadia");
combobox1_nadia=lookup_widget(objet,"combobox1_nadia");
togglebutton1_nadia=lookup_widget(objet,"radiobutton_femme_nadia");
togglebutton2_nadia=lookup_widget(objet,"radiobutton_homme_nadia");
spinbutton_age_nadia=lookup_widget(objet,"spinbutton_age_nadia");

strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1_nadia)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2_nadia)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3_nadia)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input4_nadia)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input5_nadia)));
strcpy(p.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1_nadia)));
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton1_nadia)))
strcpy(p.genre,"femme");
else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton2_nadia)))
strcpy(p.genre,"homme");

age1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_age_nadia));
sprintf(age2,"%d", age1);
strcpy(p.age,age2);

ajouter_personne(p);

}


void
on_ShowUser_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *window1_nadia;
	GtkWidget *window2_nadia;
	GtkWidget *treeview1_nadia;

	window1_nadia=lookup_widget(objet,"window1_nadia");
	window2_nadia=create_window2_nadia();

	gtk_widget_show(window2_nadia);
	gtk_widget_destroy(window1_nadia);
	treeview1_nadia=lookup_widget(window2_nadia,"treeview1_nadia");

	afficher_personne(treeview1_nadia);
}

void
on_treeview1_nadia_row_activated       (GtkTreeView     *treeview_nadia,
                                        GtkTreePath     *path_nadia,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *window2_nadia;	
	GtkTreeIter iter_nadia;
	gchar* nom;
	gchar* prenom;
	gchar* date;
	gchar* adresse;
	gchar* cin;
        gchar* role;
        gchar* genre;
        gchar* age;
	Personne p;

	GtkTreeModel *model_nadia = gtk_tree_view_get_model(treeview_nadia);

	if (gtk_tree_model_get_iter(model_nadia, &iter_nadia, path_nadia))
	{
		//obtention des valeurs de la ligne selectionnée

		gtk_tree_model_get (GTK_LIST_STORE(model_nadia), &iter_nadia, 0, &cin, 1, &nom, 2, &prenom, 3, &date, 4, &adresse, 5, &role, 6, &genre, 7, &age, -1);
		//copie des valeurs dans la variable P de type personne pour le passer  à la fonction de suppression
		strcpy(p.cin,cin);
		strcpy(p.nom,nom);
		strcpy(p.prenom,prenom);
		strcpy(p.date_naissance,date);
		strcpy(p.adresse,adresse);
                strcpy(p.role,role);
                strcpy(p.genre,genre);
                strcpy(p.age,age);
		//appel de la fonction de supression
		supprimer_personne(p);
		//mise a jour de l'affichage de la treeview
		afficher_personne(treeview_nadia);
}
}

void
on_toeditUser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1_nadia,*window3_nadia;
	window1_nadia=lookup_widget(button,"window1_nadia");
	window3_nadia = create_window3_nadia();
	gtk_widget_show (window3_nadia);
	gtk_widget_destroy(window1_nadia);
}


void
on_editUser_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
	Personne p;
char nom_cin[20];
GtkWidget	*input		=	lookup_widget(objet,"entry1_nadia");
GtkWidget	*input_cin	=	lookup_widget(objet,"entry2_nadia");
GtkWidget	*input_nom	=	lookup_widget(objet,"entry3_nadia");
GtkWidget	*input_prenom	=	lookup_widget(objet,"entry4_nadia");
GtkWidget	*input_date_naissance	=	lookup_widget(objet,"entry5_nadia");
GtkWidget	*input_adresse	=	lookup_widget(objet,"entry6_nadia");
GtkWidget       *input_role     =       lookup_widget(objet,"entry7_nadia");
GtkWidget       *input_genre    =       lookup_widget(objet,"entry8_nadia");
GtkWidget       *input_age    =       lookup_widget(objet,"entry9_nadia");

strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input_date_naissance)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input_adresse)));
strcpy(p.role,gtk_entry_get_text(GTK_ENTRY(input_role)));
strcpy(p.genre,gtk_entry_get_text(GTK_ENTRY(input_genre)));
strcpy(p.age,gtk_entry_get_text(GTK_ENTRY(input_age)));
strcpy(nom_cin,gtk_entry_get_text(GTK_ENTRY(input)));
FILE*f;

int a;
a=recherche(nom_cin);
sup_client(a);
add_client(p);

f=fopen("users.txt","a+");
if (f!=NULL)
fprintf(f,"%s %s %s %s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.adresse,p.role,p.genre,p.age);

fclose(f);
}


void
on_backShowUsers_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1_nadia, *window2_nadia;

	window2_nadia=lookup_widget(objet,"window2_nadia");
	window1_nadia=create_window1_nadia();
	gtk_widget_show(window1_nadia);
	gtk_widget_destroy(window2_nadia);
}


void
on_findUser_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
	 char cin[30];
	char nom[30];
	char prenom[30];
	char date_naissance[30];
	char adresse [30];
        char role[100];
        char genre[30];
        char age[30];
GtkWidget	*input_cin	=	lookup_widget(objet,"entry2_nadia");
GtkWidget	*input_nom	=	lookup_widget(objet,"entry3_nadia");
GtkWidget	*input_prenom	=	lookup_widget(objet,"entry4_nadia");
GtkWidget	*input_date_naissance	=	lookup_widget(objet,"entry5_nadia");
GtkWidget	*input_adresse	=	lookup_widget(objet,"entry6_nadia");
GtkWidget       *input_role     =       lookup_widget(objet,"entry7_nadia");
GtkWidget       *input_genre    =       lookup_widget(objet,"entry8_nadia");
GtkWidget       *input_age    =       lookup_widget(objet,"entry9_nadia");


char nom_cin[20];
GtkWidget	*input		=	lookup_widget(objet,"entry1_nadia");
strcpy(nom_cin,gtk_entry_get_text(GTK_ENTRY(input)));
int a=0;
a=recherche(nom_cin);
if (a==-1)
{
/*GtkWidget *window5_nadia;
window5_nadia = create_window5_nadia ();
gtk_widget_show (window5_nadia);*/
}
else 
{
modif(a,nom,prenom,date_naissance,cin,adresse,role,genre,age);
gtk_entry_set_text (GTK_ENTRY(input_nom),nom);
gtk_entry_set_text (GTK_ENTRY(input_prenom),prenom);
gtk_entry_set_text (GTK_ENTRY(input_cin),cin);
gtk_entry_set_text (GTK_ENTRY(input_adresse),adresse);
gtk_entry_set_text (GTK_ENTRY(input_date_naissance),date_naissance);
gtk_entry_set_text (GTK_ENTRY(input_role),role);
gtk_entry_set_text (GTK_ENTRY(input_genre),genre);
gtk_entry_set_text (GTK_ENTRY(input_age),age);
}
}


void
on_backEditUser_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window1_nadia, *window2_nadia;

	window2_nadia=lookup_widget(button,"window2_nadia");
	window1_nadia=create_window1_nadia();
	gtk_widget_show(window1_nadia);
	gtk_widget_destroy(window2_nadia);
}


void
on_seConnect_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window7_nadia;
	GtkWidget *input_not_admin;
	GtkWidget *combobox_integration;
	window7_nadia=lookup_widget(objet,"window7_nadia");

	combobox_integration = lookup_widget(objet,"combobox_integration");

	/*Window Administrateur*/

	if (strcmp("Administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_integration)))==0)
	{
		GtkWidget *window1_nadia;
		window1_nadia = create_window1_nadia();
		gtk_widget_show (window1_nadia);
		gtk_widget_destroy(window7_nadia);
	}

	/*Window nutrisioniste*/
	else if (strcmp("Nutrisioniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_integration)))==0)
	{
		GtkWidget *window9_nadia;
		window9_nadia = create_first();
		gtk_widget_show (window9_nadia);
		gtk_widget_destroy(window7_nadia);
	}

	/*Window AgentStock*/
	/*if (strcmp("AgentStock",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_integration)))==0)
	{
	GtkWidget *window10_nadia;
	window10_nadia = create_window10_nadia();
	gtk_widget_show (window10_nadia);
	gtk_widget_destroy(window7_nadia);
	}*/

	/*Window AgentReclamation*/
	else if (strcmp("AgentReclamation",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_integration)))==0)
	{
	GtkWidget *window11_nadia;
	window11_nadia = create_dashboard();
	gtk_widget_show (window11_nadia);
	gtk_widget_destroy(window7_nadia);
	
	}

	/*Window AgentFoyer*/
	else if (strcmp("AgentFoyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_integration)))==0)
	{
	GtkWidget *window12_nadia;
	window12_nadia = create_fenetre_ajout ();
	gtk_widget_show (window12_nadia);
	gtk_widget_destroy(window7_nadia);
	}

	/*Window TechnicienCapteur*/
	else if (strcmp("TechnicienCapteur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_integration)))==0)
	{
	GtkWidget *window13_nadia;
	window13_nadia = create_gestioncapt ();
	gtk_widget_show (window13_nadia);
	gtk_widget_destroy(window7_nadia);
	}
}
/* -------------------------------------------------------------------- */
void
on_ajouter_clicked                     (GtkWidget      *button,
                                        gpointer         user_data)
{
agent p;
GtkWidget *input1, *input2 ,*input3,*input5;
GtkWidget *combobox1,*combobox2,*combobox3,*combobox4;
GtkWidget *spinbutton;
GtkWidget *fenetre_ajout;
char s[20];
char j[20];
char m[20];
char an[20];
char niveau_[20];
char chambre[30];
char specialite[30];
int niveau;


fenetre_ajout=lookup_widget(button,"fenetre_ajout");

input1=lookup_widget(button,"cin");
input2=lookup_widget(button,"nom");
input3=lookup_widget(button,"prenom");
input5=lookup_widget(button,"telephone");
combobox1=lookup_widget(button,"FTcomboboxj");
combobox2=lookup_widget(button,"FTcomboboxm");
combobox3=lookup_widget(button,"FTcomboboxan");
combobox4=lookup_widget(button,"comboboxSp");
spinbutton=lookup_widget(button,"spinbuttonNiveau");

strcpy(j,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(m,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(an,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox3)));
strcpy(p.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));

sprintf(p.date_naissance,"%s/%s/%s",j,m,an);
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));

strcpy(p.telephone,gtk_entry_get_text(GTK_ENTRY(input5)));

niveau = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton));
sprintf(niveau_,"%d",niveau);
strcpy(p.niveau,niveau_);

resultat(choix ,texte);
strcpy(p.chambre ,texte) ;



ajouter(p);

}


void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(button,"fenetre_ajout");
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
gtk_widget_destroy(fenetre_ajout);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher(treeview1);
int choix_modif = 1;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=3; 
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=2; 
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=1; 
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nom;
gchar *prenom;
gchar *date;
gchar *telephone;
gchar *cin;
gchar *specialite;
gchar *niveau;
gchar *chambre;
GtkWidget *fenetre_afficher, *treeview1;
agent p;


GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model, &iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&cin,1,&nom,2,&prenom,3,&date,4,&telephone,5,&specialite,6,&niveau,7,&chambre,-1);
strcpy(p.cin,cin);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.date_naissance,date);
strcpy(p.telephone,telephone);
strcpy(p.specialite,specialite);
strcpy(p.niveau,niveau);
strcpy(p.chambre,chambre);
	
supprimer(p.cin);

fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher(treeview1);
fenetre_afficher=lookup_widget(treeview,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);

}

}


void
on_FTcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
*confirm=1;
else
*confirm=0;
}


void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_afficher;
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
fenetre_ajout=lookup_widget(button,"fenetre_ajout");
fenetre_ajout=create_fenetre_ajout();
gtk_widget_show(fenetre_ajout);
gtk_widget_destroy(fenetre_afficher);

choix = 3;
}


void
on_FTbutton_actualiser_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *fenetre_afficher;




fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher(treeview1);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
}


void
on_FTbuttonrech_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
char id[30];
GtkWidget *fenetre_afficher,*input;
GtkWidget *treeview1;
input=lookup_widget(button,"FTentryrech");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_agent_rechercher(treeview1,id);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);

}


void
on_FTbutton_supp_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input,*treeview;
GtkWidget *fenetre_afficher;

char id[20];
input=lookup_widget(button,"FTentry_supp");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
if(confirmer)
{supprimer(id);
fenetre_afficher=create_fenetre_afficher();
treeview=lookup_widget(fenetre_afficher,"treeview1");
gtk_widget_show(fenetre_afficher);
afficher(treeview);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);}

}


void
on_FTmodifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
agent p;
GtkWidget *input1, *input2 ,*input3,*input4,*input5,*input6,*input7,*treeview,*combobox;
GtkWidget *fenetre_afficher;
int niveau;
char niveau_[20];
char chambre[30];
char specialite[30];
input1=lookup_widget(button,"FTcin_modif");
input2=lookup_widget(button,"FTnom_modif");
input3=lookup_widget(button,"FTprenom_modif");
input4=lookup_widget(button,"FTdate_naissance_modif");
input5=lookup_widget(button,"FTtelephone_modif");
input7=lookup_widget(button,"FTspinbuttonNiveauModif");
combobox=lookup_widget(button,"comboboxSpModif");


strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.telephone,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(p.specialite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
niveau = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
sprintf(niveau_,"%d",niveau);
strcpy(p.niveau,niveau_);
resultat_modif(choix_modif,texte_modif);
strcpy(p.chambre,texte_modif);
modifier(p);
choix_modif = 1;
fenetre_afficher=create_fenetre_afficher();
treeview=lookup_widget(fenetre_afficher,"treeview1");
gtk_widget_show(fenetre_afficher);
afficher(treeview);
fenetre_afficher=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
}


void
on_A1_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix_modif=1; 
}


void
on_A2_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix_modif=2; 
}


void
on_A3_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix_modif=3; 
}

/* -------------------------- GESTION STOCK -----------------------------*/

/* ----------------------------------- */ 

FILE*f=NULL;

/*-------------------------------------*/
void
on_ajouterProduit_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{


}


void
on_ModifierProduit_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeviewStock_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_SupprimerProduit_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_checkbuttonetat_t_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonenstock_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonrept_t_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_chercher_produit_cl_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_QuitStock_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}

/* ------------------ GESTION DES MENUS ------------------------------ */ 
/* -------------------------------- */ 
int choix;
int t[9]={0,0,0,0,0,0,0,0,0};
/* -------------------------------- */
void
on_treeviewMenu_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* id;
gchar* type;
gchar* ingred;
gchar* etat; 
gchar* qut;
//char  ch1[200];
menu m;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&type,2,&ingred,3,&etat,4,&qut,-1);
strcpy(m.id,id);
strcpy(m.type,type);
strcpy(m.ingred,ingred);
strcpy(m.etat,etat);
strcpy(m.qut,qut);
//suprimer_menu(m,ch1);
affiche_menu(treeview);
}
}

void
on_bestMenu_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	 GtkWidget *first, *best;
	first=lookup_widget(objet,"first"); 
	best=create_best();
	gtk_widget_show(best);  
	gtk_widget_destroy(first);              

}


void
on_modifierMenu_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	 GtkWidget *first, *modifier;
	first=lookup_widget(objet,"first");  
	modifier=create_modifier();
	gtk_widget_show(modifier);
	gtk_widget_destroy(first);
}


void
on_ajouterMenu_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *first, *ajout;
	first=lookup_widget(objet,"first");  //first --> ajout
	ajout=create_ajout();
	gtk_widget_show(ajout);
	gtk_widget_destroy(first);
}


void
on_tosupprimerMenu_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *first, *sup;
	first=lookup_widget(objet,"first"); 
	sup=create_sup();
	gtk_widget_show(sup);  
	gtk_widget_destroy(first); 
}


void
on_afficherMenu_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *first; 
GtkWidget *treeview1;
first=lookup_widget(objet,"first");
treeview1=lookup_widget(first,"treeviewMenu");
affiche_menu(treeview1);
}


void
on_appliquerAjout_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu m;
GtkWidget *input1,*input2,*input3,*input4,*input5;
GtkWidget *ajout;
ajout=lookup_widget(objet,"ajout");
input1=lookup_widget(objet,"input1");
input2=lookup_widget(objet,"input2");
input3=lookup_widget(objet,"input3");
input4=lookup_widget(objet,"input4");
input5=lookup_widget(objet,"input5");
strcpy(m.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(m.type,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(m.ingred,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(m.etat,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(m.qut,gtk_entry_get_text(GTK_ENTRY(input5)));
ajout_menu(m);

}


void
on_retourAjoutM_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *first, *ajout;
	ajout=lookup_widget(objet,"ajout");  
	gtk_widget_destroy(ajout);
	first=create_first();
	gtk_widget_show(first);
	
}


void
on_radiobuttonPDej_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=0;
}


void
on_radiobuttonDej_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=1;
}


void
on_radiobuttonDiner_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=2;
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[0]=1;
	}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[1]=1;
	}
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[2]=1;
	}
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[3]=1;
	}
}


void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[4]=1;
	}
}


void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[5]=1;
	}
}


void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[6]=1;
	}
}


void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[7]=1;
	}
}


void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
	{
	t[8]=1;
	}
}


void
on_appModifier_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *entry_idmod;
GtkWidget *modifier;
GtkWidget *spinbutton1;
GtkWidget *comboboxentry1;
int x;
menu m;
char ch1[22];
modifier=lookup_widget(objet,"modifier");
entry_idmod=lookup_widget(objet,"entry_idmod");
strcpy(m.id,gtk_entry_get_text(GTK_ENTRY(entry_idmod)));
strcpy(ch1,m.id);
if(choix==0)

strcpy(m.type,"petit_dejeuner");
else 
if(choix==1)
strcpy(m.type,"dejeuner");
else
if(choix==2)
strcpy(m.type,"diner");
if (t[0]==1)
strcpy(m.ingred," lait");
else 

if (t[1]==1)
strcpy(m.ingred,"jus");
else
if (t[2]==1)
strcpy(m.ingred,"viande");
else 
if (t[3]==1)
strcpy(m.ingred,"poisson");
else 
if (t[4]==1)
strcpy(m.ingred,"cereale");
else 
if (t[5]==1)
strcpy(m.ingred,"fruit");
else 
if (t[6]==1)
strcpy(m.ingred,"poulet");
else 
if (t[7]==1)
strcpy(m.ingred,"pate");
else 
if (t[8]==1)
strcpy(m.ingred,"salade");
comboboxentry1=lookup_widget(objet,"comboboxentry1");
spinbutton1=lookup_widget(objet,"spinbutton1");
strcpy(m.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)));
x=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
sprintf(m.qut,"%d",x);
//modifier_menu(ch1,m);
ajout_menu(m);
}


void
on_ret_modM_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *first, *modifier;
modifier=lookup_widget(objet,"modifier");  
gtk_widget_destroy(modifier);
first=create_first();
gtk_widget_show(first);
}


void
on_supprimerMenu_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *entry3;
menu m;
char ch1[20];
entry3=lookup_widget(objet,"entry3");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(entry3)));
suprimer_menu(m,ch1);
}


void
on_retourSuppM_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *first, *supprimer;
supprimer=lookup_widget(objet,"sup");  
gtk_widget_destroy(supprimer);
first=create_first();
gtk_widget_show(first);
}


void
on_rechercheMenu_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
char ch1[30];
menu m;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
output1=lookup_widget(objet,"type");
output2=lookup_widget(objet,"ingred");
output3=lookup_widget(objet,"etat");
output4=lookup_widget(objet,"qut");
GtkWidget *entry_recherche;
entry_recherche=lookup_widget(objet,"entry_recherche");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(entry_recherche)));
m=chercher_menu (ch1);
gtk_label_set_text(GTK_LABEL(output1),m.type);
gtk_label_set_text(GTK_LABEL(output2),m.ingred);
gtk_label_set_text(GTK_LABEL(output3),m.etat);
gtk_label_set_text(GTK_LABEL(output4),m.qut);
}


void
on_retourBestM_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *first, *best;
	best=lookup_widget(objet,"best");  
	first=create_first();
	gtk_widget_show(first);
	gtk_widget_destroy(best);
}

/* ---------------------- GESTION DES CAPTEURS -------------------- */ 
/* ------------------ variables globales --------------------*/
int x,y,z[]={0,0,0,0};

/* ------------------------------------------------------- */ 
void
on_chercherCap_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *ref,*treeview,*gestioncapt,*label27erreurrecherche;
	char ref1[20];
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	treeview=lookup_widget (gestioncapt,"treeview1hanen");
	ref=lookup_widget (objet_graphique,"entry1capt");
	strcpy(ref1,gtk_entry_get_text(GTK_ENTRY(ref)));
	if(strcmp(ref1,"")!=0)
	{
		if(existcapt(ref1))
		{
			rechercher_cap(ref1);
			afficher_capt(treeview,"recherche.txt");
			remove("recherche.txt");
		}
		else{
			label27erreurrecherche=lookup_widget(objet_graphique,"label27erreurrecherche");
			gtk_label_set_text(GTK_LABEL(label27erreurrecherche),"Reference n'existe pas");
		}
	}
	else
		afficher_capt(treeview,"capteur.txt");
}


void
on_refreshTreeCap_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview,*label27erreurrecherche,*label11capt,*label19capt,*label26capt;
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	treeview=lookup_widget (gestioncapt,"treeview1hanen");
	afficher_capt(treeview,"capteur.txt");
	
}


void
on_supprimerCap_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview,*label11capt;
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
	gchar* ref;
	gint zone;
	gint min;
	gint max;
	gint etat;
	gint type;
	
	gestioncapt=lookup_widget(objet_graphique,"gestioncapt");
        treeview=lookup_widget(gestioncapt,"treeview1hanen");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_tree_model_get (model,&iter,0,&ref,1,&zone,2,&min,3,&max,4,&etat,5,&type,-1);
		supprimer_capt(ref,"capteur.txt");
		supprimer_capt(ref,"temperature.txt");
		supprimer_capt(ref,"mouvement.txt");
		supprimer_capt(ref,"smoke.txt");
		supprimer_capt(ref,"debit.txt");
		supprimer_capt(ref,"temperaturedef.txt");
		supprimer_capt(ref,"mouvementdef.txt");
		supprimer_capt(ref,"smokedef.txt");
		supprimer_capt(ref,"debitdef.txt");
		afficher_capt(treeview,"capteur.txt");
		label11capt=lookup_widget(objet_graphique,"label11capt");
		gtk_label_set_text(GTK_LABEL(label11capt),"capteur supprimée");
	}
}


void
on_ajouterCap_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *captref,*captzone,*captmin,*captmax,*capttype,*label19capt,*labelajout;
	int b=1;
	capteur c;
	captref=lookup_widget (objet_graphique,"entry2capt");
	captmax=lookup_widget (objet_graphique,"spinbutton1hanen");
	captmin=lookup_widget (objet_graphique,"spinbutton2hanen");
	capttype=lookup_widget (objet_graphique,"comboboxtype_capteur");
	captzone=lookup_widget (objet_graphique,"comboboxentrytype");
	labelajout=lookup_widget (objet_graphique,"label32");
	strcpy(c.captref,gtk_entry_get_text(GTK_ENTRY(captref)));
	if(strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=1;
	else if(strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=2;
	
	else
		c.captzone=3;
	if(strcmp("Temperature",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=0;
	else if(strcmp("Mouvement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=1;
	else if(strcmp("Fumer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=2;
	else
		c.type=3;
	
	c.c.captvaleurmax=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmax));
	c.c.captvaleurmin=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmin));
	c.etat=y;
      if(strcmp(c.captref,"")==0){
	gtk_widget_show (labelajout);
	b=0;}
	else{
	gtk_widget_hide (labelajout);
	}
	if(b==1){
	ajout_capt(c);
	label19capt=lookup_widget(objet_graphique,"label19capt");
	gtk_label_set_text(GTK_LABEL(label19capt),"verifier vos données");
	}

}


void
on_ensregistrerCap_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *captref,*captzone,*captmin,*captmax,*capttype,*label26capt;
	
	capteur c;
	captref=lookup_widget (objet_graphique,"entry3capt");
	captmax=lookup_widget (objet_graphique,"spinbutton3hanen");
	captmin=lookup_widget (objet_graphique,"spinbutton4hanen");
	capttype=lookup_widget (objet_graphique,"comboboxentry5");
	captzone=lookup_widget (objet_graphique,"comboboxentry2");
	strcpy(c.captref,gtk_entry_get_text(GTK_ENTRY(captref)));
	if(strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=1;
	else if(strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(captzone)))==0)
		c.captzone=2;
	
	else
		c.captzone=3;
	if(strcmp("Temperature",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=0;
	else if(strcmp("Mouvement",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=1;
	else if(strcmp("Fumer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(capttype)))==0)
		c.type=2;
	else
		c.type=3;
	
	c.c.captvaleurmax=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmax));
	c.c.captvaleurmin=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (captmin));
	c.etat=x;
	modifier_capt(c);
	label26capt=lookup_widget(objet_graphique,"label26capt");
	gtk_label_set_text(GTK_LABEL(label26capt),"Modification Enregistrée");
}


void
on_checkbutton1hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		z[0]=1;
}


void
on_checkbutton2hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		z[1]=1;
}


void
on_checkbutton3hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		z[2]=1;
}


void
on_checkbutton4hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
		z[3]=1;
}


void
on_buttonDiffective_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview,*cb1,*cb2,*cb3,*cb4;
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	cb1=lookup_widget (objet_graphique,"checkbutton1hanen");
	cb2=lookup_widget (objet_graphique,"checkbutton2hanen");
	cb3=lookup_widget (objet_graphique,"checkbutton3hanen");
	cb4=lookup_widget (objet_graphique,"checkbutton4hanen");
	treeview=lookup_widget (gestioncapt,"treeview2hanen");
	capteurparchoix(z);
	afficher_capt(treeview,"capteurchoix.txt");
	remove("capteurchoix.txt");
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb1), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb2), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb3), FALSE);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cb4), FALSE);
	z[0]=0;
	z[1]=0;
	z[2]=0;
	z[3]=0;
}


void
on_nombreCapDef_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	char resultat[200]="";
	GtkWidget *aff,*aff1;	
	FILE *f,*g;
	f=fopen("temperature1.txt","r");
	g=fopen("capteurdefectueux.txt","a+");
	capteurTemperature c,T[5000];
	int i=0,n=0,nb=0;
	if(f!=NULL){
			
			while(!feof(f))
			{
				fscanf(f,"%d %d %d %f\n",&c.jourc,&c.heurec,&c.numC,&c.valT);
				
				T[i].jourc=c.jourc;
				T[i].heurec=c.heurec;
				T[i].numC=c.numC;
				T[i].valT=c.valT;
				i++;
			}
			fclose(f);
			n=i;
	}
	for(i=0;i<n;i++){
		if(T[i].valT<10 || T[i].valT>30){
			fprintf(g,"%d %d %d %f\n",T[i].jourc,T[i].heurec,T[i].numC,T[i].valT);
			nb++;
		}
	}
	sprintf(resultat,"le nombre de capteur defecteux est :%d/%d\n",nb,n);

        aff=lookup_widget(objet_graphique,"label29hanen");
	gtk_label_set_text(GTK_LABEL(aff),resultat);
}


void
on_refreshTreeDef_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *gestioncapt,*treeview3hanen;
	gestioncapt=lookup_widget (objet_graphique,"gestioncapt");
	treeview3hanen=lookup_widget (gestioncapt,"treeview3hanen");
	

	afficher_captdefectueux(treeview3hanen,"capteurdefectueux.txt");	
}


void
on_radiobutton3hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		x=1;
	}
}


void
on_radiobutton4hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		x=0;
	}
}


void
on_radiobutton1hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		y=1;
	}
}


void
on_radiobutton2hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	{
		y=0;
	}
}

/* -------------------------------------------------------------------------------- */ 

void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *aj, *dashboard;
dashboard=lookup_widget(objet,"dashboard");
aj=lookup_widget(objet,"aj");
aj=create_aj();
gtk_widget_show(aj);

}


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *mod, *dashboard;
dashboard=lookup_widget(objet,"dashboard");
mod=lookup_widget(objet,"mod");
mod=create_mod();
gtk_widget_show(mod);

}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{/*GtkWidget *treeview, *af;
af=lookup_widget(objet,"af");
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeview");
afficher(treeview,"reclamations.txt");*/

}


void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
/*GtkWidget *pInfo;
char str[1000], ch[1000]="";
strcpy(ch,plus_reclame("reclamations.txt"));
sprintf(str,"%s",ch);
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;*/
}


void
on_aj_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_mod_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_af_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview8_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_aff_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}

