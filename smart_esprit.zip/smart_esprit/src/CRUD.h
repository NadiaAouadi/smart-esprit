#ifndef REPAS__H__
#define REPAS__H__

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <gtk/gtk.h>
#include <string.h>

typedef struct{
	int jour;
	int mois;
	int annee;
}date;

typedef struct{
	char id[20];
	char nom[20];
	char prix[20];
	date date1;
	date date2;
	char fournisseur[30];
	char rangement[30];
	char quantity[30];

}produit;
void ajouter_produit( produit c);
int exist_produit(char*id);
void supprimer_produit(char*id);

#endif
