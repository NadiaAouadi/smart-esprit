#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "personne.h"
#define MAX 256



enum
{
	ECIN,
	ENOM,
	EPRENOM,
	EDATE,
	EADRESSE,
        EROLE,
        EGENRE,
        EAGE,
	COLUMNS
};
/**-----------------[Ajouter]----------------**/
void ajouter_personne (Personne p)
{
int gendre;
FILE*f;
f=fopen("users.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.adresse,p.role,p.genre,p.age);
fclose(f);
}}
/**----------------[Afficher]----------------**/
void afficher_personne(GtkWidget *liste)
{

FILE*f;
Personne p;

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char cin[30];
	char nom[30];
	char prenom[30];
	char date_naissance[30];
	char adresse [30];
        char role[100];
        char genre[30];
        char age[30];
	store=NULL;
	store=gtk_tree_view_get_model(liste);

if (store==NULL)
{
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("date_inscription", renderer, "text",EDATE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("adresse", renderer, "text",EADRESSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
        
        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("role", renderer, "text",EROLE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("genre", renderer, "text",EGENRE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("age", renderer, "text",EAGE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
       
}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);


	f=fopen("users.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f = fopen("users.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date_naissance,adresse,role,genre,age)!=EOF)
		{
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store,&iter,ECIN,cin,ENOM,nom,EPRENOM, prenom,EDATE,date_naissance,EADRESSE,adresse,EROLE,role,EGENRE,genre,EAGE,age, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
}

/**----------------[Supprimer]----------------**/
void supprimer_personne (Personne p)
{

FILE*f1;
FILE*f2;
Personne p2;

	f1=fopen("users.txt","r");
	f2=fopen("users2.txt","w");

	if (f1==NULL || f2==NULL)
		return;
	else
	{
		while(fscanf(f1,"%s %s %s %s %s %s %s %s \n",p2.cin,p2.nom,p2.prenom,p2.date_naissance,p2.adresse,p2.role,p2.genre,p2.age)!=EOF)
		{
			if(strcmp(p.cin,p2.cin)!=0 || strcmp(p.nom,p2.nom)!=0 || strcmp(p.prenom,p2.prenom)!=0 || strcmp(p.date_naissance,p2.date_naissance)!=0 || strcmp(p.adresse,p2.adresse)!=0 || strcmp(p.role,p2.role)!=0 || strcmp(p.genre,p2.genre)!=0 || strcmp(p.age,p2.age)!=0)
			fprintf(f2,"%s %s %s %s %s %s %s %s \n",p2.cin,p2.nom,p2.prenom,p2.date_naissance,p2.adresse,p2.role,p2.genre,p2.age);
		}
		fclose(f1);
		fclose(f2);
remove("users.txt");
rename("users2.txt","users.txt");
}
	}
/**-----------------------------------------------------------------------------------[Modifier + Recherche]-------------------------------------------------------------------------------**/

/**-------------[Search To Edit]---------------**/
int recherche(char nom_cin[])
{
	char cin[30];
	char nom[30];
	char prenom[30];
	char date_naissance[30];
	char adresse [30];
        char role[30];
        char genre[30];
        char age[30];
	int ligne=0;
FILE*f;
f=fopen("users.txt","r"); 
if(f!=NULL) 
	{
		while(fscanf(f,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date_naissance,adresse,role,genre,age)!=EOF)
		{
                        ligne++;
			if(strcmp(nom_cin,nom)==0)
			{
                        fclose(f);
			return(ligne);
			}
			if(strcmp(nom_cin,cin)==0)
			{
			fclose(f);
			return(ligne);
			}
		}
		fclose(f);
		return(-1);
	}
	return(-1);
}

/**-------------[Edit]-----------------**/

void modif(int a,char nom[20],char prenom[20],char date_naissance[20],char cin[10],char adresse[100], char role[100],char genre[30], char age[30])
{


    FILE *f;
    f=fopen("users.txt", "r");
    int line=0;
    while(fscanf(f,"%s %s %s %s %s %s %s %s \n",cin,nom,prenom,date_naissance,adresse,role,genre,age)!=EOF) 
{
        line++;
        if(line == a) break;
}
fclose(f);
}

/**--------[add client]-------**/

void add_client(Personne p)
{
FILE*f;
f=fopen("users.txt","a+");
if (f!=NULL)
{ fprintf(f,"%s %s %s %s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.adresse,p.role,p.genre,p.age);
fclose(f);
}}

/**--------[supp client]-------**/

void sup_client(int lno)
{
int ctr = 0;
        char ch;
        FILE *f1, *f2;
		char fname[MAX];
        char str[MAX], temp[] = "temp.txt";
					
        f1 = fopen("users.txt", "r");
        f2 = fopen("temp.txt", "w"); 
        lno++;
        while (!feof(f1)) 
        {
            strcpy(str, "\0");
            fgets(str, MAX, f1);
            if (!feof(f1)) 
            {
                ctr++;
                if (ctr != (lno-1)) 
                {
                    fprintf(f2, "%s", str);
                }
            }
        }
        fclose(f1);
        fclose(f2);
        remove("users.txt");  		
        rename("temp.txt","users.txt");
}

