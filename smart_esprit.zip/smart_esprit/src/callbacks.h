#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_FTcheckbutton1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbutton_actualiser_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbuttonrech_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTbutton_supp_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_FTmodifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_A1_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_A2_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_A3_modif_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouterProduit_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierProduit_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewStock_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_SupprimerProduit_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbuttonetat_t_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonenstock_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonrept_t_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chercher_produit_cl_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_QuitStock_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewMenu_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_bestMenu_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierMenu_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterMenu_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_tosupprimerMenu_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherMenu_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_appliquerAjout_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourAjoutM_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonPDej_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDej_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDiner_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_appModifier_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_modM_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerMenu_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourSuppM_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercheMenu_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourBestM_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

/* ------------------------------------------------------------------------ */ 

void
on_chercherCap_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_refreshTreeCap_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerCap_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_ajouterCap_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_ensregistrerCap_clicked             (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonDiffective_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_nombreCapDef_clicked                (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_refreshTreeDef_clicked              (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton3hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2hanen_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_addUser_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_ShowUser_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_editUser_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_backShowUsers_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_findUser_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_backEditUser_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_seConnect_clicked                   (GtkButton       *objet,
                                        gpointer         user_data);

void
on_toeditUser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_editUser_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_nadia_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aj_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_mod_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_af_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview8_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_aff_clicked                         (GtkButton       *button,
                                        gpointer         user_data);
