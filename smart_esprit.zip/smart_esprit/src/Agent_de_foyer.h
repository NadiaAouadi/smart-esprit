#include <gtk/gtk.h>

typedef struct
{
char cin[20];
char nom[20];
char prenom[30];
char date_naissance[30];
char telephone[30];
char specialite[20];
char niveau[20];
char chambre [30];



}agent;
void ajouter(agent p);
void afficher(GtkWidget *liste);
void supprimer(char id[]);
void modifier(agent p);
void rechercher(char nomFichier[],char texte[],char id[]);
void afficher_agent_rechercher(GtkWidget *liste,char id[]);
void resultat(int choix , char texte[] );
void resultat_modif(int choix , char texte[] );







