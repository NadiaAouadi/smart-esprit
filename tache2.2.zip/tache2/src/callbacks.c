#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "alarme.h"

void
on_button_ajm_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *h, *m;
GtkCalendar *ajc;
mesure u;
guint day, month, year;
aj1=lookup_widget(objet,"ajm1");
aj2=lookup_widget(objet,"ajm2");
aj3=lookup_widget(objet,"ajm3");
aj4=lookup_widget(objet,"ajm4");
ajc=lookup_widget(objet,"ajmc");
h=lookup_widget(objet,"h");
m=lookup_widget(objet,"m");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3)));
strcpy(u.etage,gtk_entry_get_text(GTK_ENTRY(aj4)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
u.h=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(h));
u.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
ajouter_mesure(u,"mesures.txt");
}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *def;
def=lookup_widget(objet,"def");
gtk_widget_destroy(def);
def=lookup_widget(objet,"def");
def=create_def();
gtk_widget_show(def);
treeview=lookup_widget(def,"treeview_def");
alarme(treeview,"mesures.txt");
}


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_mesure, *def;
def=lookup_widget(objet,"def");
aj_mesure=lookup_widget(objet,"aj_mesure");
aj_mesure=create_aj_mesure();
gtk_widget_show(aj_mesure);
}

