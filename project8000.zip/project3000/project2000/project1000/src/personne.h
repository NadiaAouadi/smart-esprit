#include <gtk/gtk.h>

typedef struct 
{
char cin[30];
char nom[30];
char prenom[30];
char date_naissance[30];
char adresse [30];
char role[100];
char genre[30];
char age[30];

} Personne;

void ajouter_personne(Personne p);
void afficher_personne(GtkWidget *liste);
void supprimer_personne(Personne p);
int recherche(char nom_cin[]);
void modif(int a,char nom[20],char prenom[20],char date_naissance[20],char cin[10],char adresse[100],char role[100],char genre[30],char age[30]);
void sup_client(int lno);
void add_client(Personne p);
