#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "personne.h"
#include <string.h>


void
on_ajout_clicked                       (GtkButton       *objet,
                                        gpointer         user_data)
{
Personne p;
int age1;
char age2[30];

GtkWidget *input1, *input2, *input3, *input4, *input5;
GtkWidget *window1;
GtkWidget *combobox1;
GtkWidget *togglebutton1, *togglebutton2;
GtkWidget *spinbutton_age;

window1=lookup_widget(objet,"window1");

input1=lookup_widget(objet,"input1");
input2=lookup_widget(objet,"input2");
input3=lookup_widget(objet,"input3");
input4=lookup_widget(objet,"input4");
input5=lookup_widget(objet,"input5");
combobox1=lookup_widget(objet,"combobox1");
togglebutton1=lookup_widget(objet,"radiobutton_femme");
togglebutton2=lookup_widget(objet,"radiobutton_homme");
spinbutton_age=lookup_widget(objet,"spinbutton_age");

strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(p.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton1)))
strcpy(p.genre,"femme");
else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton2)))
strcpy(p.genre,"homme");

age1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_age));
sprintf(age2,"%d", age1);
strcpy(p.age,age2);

ajouter_personne(p);

if (strcmp(strcpy(p.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))),"etudiant")==0)
{
GtkWidget *window6;
window6 = create_window6 ();
gtk_widget_show (window6);
}
}


void
on_afficher_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
Personne p;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;

window1=lookup_widget(objet,"window1");

gtk_widget_destroy(window1);
window2=lookup_widget(objet,"window2");
window2=create_window2();

gtk_widget_show(window2);

treeview1=lookup_widget(window2,"treeview1");

afficher_personne(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *window2;	
	GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* date;
	gchar* adresse;
	gchar* cin;
        gchar* role;
        gchar* genre;
        gchar* age;
	Personne p;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		//obtention des valeurs de la ligne selectionnée

		gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &cin, 1, &nom, 2, &prenom, 3, &date, 4, &adresse, 5, &role, 6, &genre, 7, &age, -1);
		//copie des valeurs dans la variable P de type personne pour le passer  à la fonction de suppression
		strcpy(p.cin,cin);
		strcpy(p.nom,nom);
		strcpy(p.prenom,prenom);
		strcpy(p.date_naissance,date);
		strcpy(p.adresse,adresse);
                strcpy(p.role,role);
                strcpy(p.genre,genre);
                strcpy(p.age,age);
		//appel de la fonction de supression
		supprimer_personne(p);
		//mise a jour de l'affichage de la treeview
		afficher_personne(treeview);
}
}


void
on_back_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1, *window2;

window2=lookup_widget(objet,"window2");

gtk_widget_destroy(window2);
window1=create_window1();
gtk_widget_show(window1);
}


void
on_recherche_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
char cin[30];
	char nom[30];
	char prenom[30];
	char date_naissance[30];
	char adresse [30];
        char role[100];
        char genre[30];
        char age[30];
GtkWidget	*input_cin	=	lookup_widget(objet,"entry2");
GtkWidget	*input_nom	=	lookup_widget(objet,"entry3");
GtkWidget	*input_prenom	=	lookup_widget(objet,"entry4");
GtkWidget	*input_date_naissance	=	lookup_widget(objet,"entry5");
GtkWidget	*input_adresse	=	lookup_widget(objet,"entry6");
GtkWidget       *input_role     =       lookup_widget(objet,"entry7");
GtkWidget       *input_genre    =       lookup_widget(objet,"entry8");
GtkWidget       *input_age    =       lookup_widget(objet,"entry9");


char nom_cin[20];
GtkWidget	*input		=	lookup_widget(objet,"entry1");
strcpy(nom_cin,gtk_entry_get_text(GTK_ENTRY(input)));
int a=0;
a=recherche(nom_cin);
if (a==-1)
{
GtkWidget *window5;
window5 = create_window5 ();
gtk_widget_show (window5);
}
else 
{
modif(a,nom,prenom,date_naissance,cin,adresse,role,genre,age);
gtk_entry_set_text (GTK_ENTRY(input_nom),nom);
gtk_entry_set_text (GTK_ENTRY(input_prenom),prenom);
gtk_entry_set_text (GTK_ENTRY(input_cin),cin);
gtk_entry_set_text (GTK_ENTRY(input_adresse),adresse);
gtk_entry_set_text (GTK_ENTRY(input_date_naissance),date_naissance);
gtk_entry_set_text (GTK_ENTRY(input_role),role);
gtk_entry_set_text (GTK_ENTRY(input_genre),genre);
gtk_entry_set_text (GTK_ENTRY(input_age),age);
}
}


void
on_edit_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
Personne p;
char nom_cin[20];
GtkWidget	*input		=	lookup_widget(objet,"entry1");
GtkWidget	*input_cin	=	lookup_widget(objet,"entry2");
GtkWidget	*input_nom	=	lookup_widget(objet,"entry3");
GtkWidget	*input_prenom	=	lookup_widget(objet,"entry4");
GtkWidget	*input_date_naissance	=	lookup_widget(objet,"entry5");
GtkWidget	*input_adresse	=	lookup_widget(objet,"entry6");
GtkWidget       *input_role     =       lookup_widget(objet,"entry7");
GtkWidget       *input_genre    =       lookup_widget(objet,"entry8");
GtkWidget       *input_age    =       lookup_widget(objet,"entry9");

strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input_date_naissance)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input_adresse)));
strcpy(p.role,gtk_entry_get_text(GTK_ENTRY(input_role)));
strcpy(p.genre,gtk_entry_get_text(GTK_ENTRY(input_genre)));
strcpy(p.age,gtk_entry_get_text(GTK_ENTRY(input_age)));
strcpy(nom_cin,gtk_entry_get_text(GTK_ENTRY(input)));
FILE*f;

int a;
a=recherche(nom_cin);
sup_client(a);
add_client(p);

f=fopen("users.txt","a+");
if (f!=NULL)
fprintf(f,"%s %s %s %s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.adresse,p.role,p.genre,p.age);

fclose(f);
}

void
on_button_niv_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *combobox2;
FILE *f;
char nivo[30];
combobox2=lookup_widget(objet,"combobox2");
strcpy(nivo,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
f= fopen("niv.txt","a+");
if (f != NULL){
fprintf(f,"%s\n",nivo);
}
fclose(f);
}


void
on_button_rech_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
char niveau[10];
int n1=0 , n2=0 , n3=0;
char texte[20];
char texte2[20];
char texte3[20];

GtkWidget	*output		=	lookup_widget(objet,"label19");
GtkWidget	*output2	=	lookup_widget(objet,"label20");
GtkWidget	*output3	=	lookup_widget(objet,"label21");


FILE*f;
f=fopen("niv.txt","r"); 
if(f!=NULL)

while (fscanf(f,"%s\n",niveau)!=EOF)
	{
           if (strcmp(niveau,"1") == 0)
	   n1++;
	   else if (strcmp(niveau,"2") == 0)
	   n2++;
	   else if (strcmp(niveau,"3") == 0)
	   n3++;
	}


sprintf(texte ,"%d", n1);
sprintf(texte2 ,"%d", n2);
sprintf(texte3 ,"%d", n3);

gtk_label_set_text(output,texte);
gtk_label_set_text(output2,texte2);
gtk_label_set_text(output3,texte3);
}


void
on_button_seconnecter_nadia_clicked    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window7;
GtkWidget *input_not_admin;
window7=lookup_widget(objet,"window7");
input_not_admin = lookup_widget(objet,"entry_mdp_nadia");
if (strcmp("14351935",gtk_entry_get_text(GTK_ENTRY(input_not_admin)))==0)
{
GtkWidget *window1;
window1 = create_window1();
gtk_widget_show (window1);
}
else 
{
GtkWidget *window8;
window8 = create_window8();
gtk_widget_show (window8);
}
}


void
on_button_rechercher_admin_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3 = create_window3();
gtk_widget_show (window3);
}


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton1,
                                        gpointer         user_data)
{
}


void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton2,
                                        gpointer         user_data)
{
}

