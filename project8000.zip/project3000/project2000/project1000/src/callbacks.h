#include <gtk/gtk.h>


void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_back_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherche_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_edit_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_calculer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_niv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_seconnecter_nadia_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_admin_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
