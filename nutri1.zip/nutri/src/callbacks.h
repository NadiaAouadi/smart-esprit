#include <gtk/gtk.h>


void
on_button_modif_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajout_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_app_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supp_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_affiche_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ret_aff_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_ajout_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_mod_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_sup_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_appajout_clicked             (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_recherche_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_best_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ret_bestt_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
